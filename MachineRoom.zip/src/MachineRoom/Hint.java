package MachineRoom;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Hint //��ʾ����
{	
	JLabel l3=new JLabel();
	JFrame f=new JFrame("��ʾ");
	Hint(String s)
	{
	f.setSize(300, 80);
	f.setLocationRelativeTo(null);//���ô�������Ļ����
	JPanel panel=new JPanel();
	panel.add(l3);
	l3.setText(s);
	f.add(panel,BorderLayout.CENTER);
	f.setVisible(true);
	}
}
